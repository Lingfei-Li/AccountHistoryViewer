
exports.AWS_REGION = 'us-west-2';
exports.DDB_ENDPOINT = 'http://localhost:3001';
exports.TABLE_NAME = 'TransactionHistory';
